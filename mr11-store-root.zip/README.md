# mr_11_store

Luxury perfume combos and accessories shop. Delivery all over the UAE and Qatar. Orders go through WhatsApp.

Plain HTML, CSS and JavaScript. No build step and nothing to install.

## Edit products and phone numbers
Open `js/products.js`. Change the `STORE` block for phone numbers and the `PRODUCTS` list for products, prices and offers.

## Add photos
Copy your photos into `images/` using the names in `images/README.txt`.

## Run locally
Open `index.html` in a browser, or run `python3 -m http.server` in this folder and visit http://localhost:8000.

## Publish for free on GitHub Pages
1. Create a new repository on GitHub and upload all files in this folder.
2. Go to Settings, then Pages.
3. Under Source choose "Deploy from a branch", pick `main` and `/ (root)`, then Save.
4. Your site goes live at `https://<your-username>.github.io/<repo-name>/` within a minute or two.
