Put your product photos here with these exact names (or change the names in js/products.js):
  product-1.jpg  Afleyk World Map Mini Set
  product-2.jpg  Afleyk Light Fragrance 200ml
  product-3.jpg  Luxury Gift Box Perfume Trio
  product-4.jpg  Perfume Mix, 10 Pieces
  product-5.jpg  G.L Wear X6 Smart Band
Until a photo is added, the site shows a "Photo coming soon" placeholder.
