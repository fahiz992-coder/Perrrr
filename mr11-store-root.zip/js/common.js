// Shared helpers + header/footer/floating WhatsApp button.
const money = n => `${n} ${STORE.currency}`;
const waLink = (number, text) => `https://wa.me/${number}?text=${encodeURIComponent(text)}`;
const orderText = p => `Hello ${STORE.name}, I want to order: ${p.name} – ${p.offer} (${money(p.price)}). Please confirm availability.`;

// Inline placeholder shown when a product photo is missing.
const PLACEHOLDER = "data:image/svg+xml;utf8," + encodeURIComponent(
  `<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 400 400'><rect width='400' height='400' fill='#161616'/><rect x='20' y='20' width='360' height='360' fill='none' stroke='#C9A24B' stroke-opacity='.4'/><text x='200' y='205' fill='#C9A24B' font-family='Georgia,serif' font-size='22' text-anchor='middle'>Photo coming soon</text></svg>`);
const imgFallback = img => { img.onerror = null; img.src = PLACEHOLDER; };

function renderChrome() {
  const links = [["index.html", "Home"], ["index.html#offers", "Offers"], ["index.html#shop", "Shop"], ["index.html#contact", "Contact"]];
  document.getElementById("site-header").innerHTML = `
    <div class="wrap bar">
      <a class="brand" href="index.html">${STORE.name}</a>
      <button class="menu-btn" aria-label="Open menu" aria-expanded="false">Menu</button>
      <nav class="nav">${links.map(([h, t]) => `<a href="${h}">${t}</a>`).join("")}</nav>
    </div>`;
  const btn = document.querySelector(".menu-btn"), nav = document.querySelector(".nav");
  btn.addEventListener("click", () => btn.setAttribute("aria-expanded", nav.classList.toggle("open")));

  document.getElementById("site-footer").innerHTML = `
    <div class="wrap foot">
      <div><strong class="brand">${STORE.name}</strong><p>Perfume combos and accessories. Delivery all over the UAE and Qatar.</p></div>
      <div class="foot-links"><a href="index.html#shop">Shop</a><a href="index.html#offers">Offers</a><a href="index.html#contact">Contact</a></div>
      <p class="copy">© ${new Date().getFullYear()} ${STORE.name}</p>
    </div>`;

  const fab = document.createElement("a");
  fab.className = "fab";
  fab.href = waLink(STORE.whatsappUAE, `Hello ${STORE.name}, I have a question.`);
  fab.target = "_blank"; fab.rel = "noopener";
  fab.textContent = "WhatsApp us";
  document.body.appendChild(fab);
}
