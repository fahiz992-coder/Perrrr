// Product detail page: /product.html?id=<product id>
renderChrome();
const id = new URLSearchParams(location.search).get("id");
const p = PRODUCTS.find(x => x.id === id);
const root = document.getElementById("product");

if (!p) {
  root.innerHTML = `<div class="wrap"><h1>Product not found</h1><p>This product is not available. <a href="index.html#shop">Back to the shop</a></p></div>`;
} else {
  document.title = `${p.name} | ${STORE.name}`;
  root.innerHTML = `
  <div class="wrap detail">
    <div class="gallery">
      <img id="main-img" src="${p.images[0]}" alt="${p.name}" onerror="imgFallback(this)">
      ${p.images.length > 1 ? `<div class="thumbs">${p.images.map((s, i) =>
        `<button aria-label="Show photo ${i + 1}" data-src="${s}"><img src="${s}" alt="" onerror="imgFallback(this)"></button>`).join("")}</div>` : ""}
    </div>
    <div class="info">
      <a class="back" href="index.html#shop">Back to the shop</a>
      <span class="tag">${p.offer}</span>
      <h1>${p.name}</h1>
      <p class="price big">${money(p.price)}</p>
      <p>${p.description}</p>
      <ul class="facts">
        <li>${p.freeDelivery ? "Free delivery" : "Delivery"} across the UAE and Qatar</li>
        <li>Order by WhatsApp. No online payment needed</li>
      </ul>
      <a class="btn big" href="${waLink(STORE.whatsappUAE, orderText(p))}" target="_blank" rel="noopener">Order on WhatsApp (UAE)</a>
      <a class="btn ghost big" href="${waLink(STORE.whatsappQatar, orderText(p))}" target="_blank" rel="noopener">Order from Qatar</a>
    </div>
  </div>
  <section class="wrap related"><h2>You may also like</h2><div class="grid" id="related"></div></section>`;

  document.querySelectorAll(".thumbs button").forEach(b =>
    b.addEventListener("click", () => document.getElementById("main-img").src = b.dataset.src));

  document.getElementById("related").innerHTML = PRODUCTS.filter(x => x.id !== p.id).slice(0, 3).map(x => `
    <article class="card">
      <a href="product.html?id=${x.id}" class="card-img"><img src="${x.images[0]}" alt="${x.name}" loading="lazy" onerror="imgFallback(this)"></a>
      <div class="card-body"><span class="tag">${x.offer}</span><h3><a href="product.html?id=${x.id}">${x.name}</a></h3><p class="price">${money(x.price)}</p></div>
    </article>`).join("");
}
