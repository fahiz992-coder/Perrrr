// ============================================================
//  EDIT THIS FILE to change products, prices and phone numbers.
//  Put product photos in /images and list the file names below.
// ============================================================

const STORE = {
  name: "mr_11_store",
  currency: "AED",
  whatsappUAE: "971561871837",   // WhatsApp orders (UAE)
  whatsappQatar: "97471929933",  // WhatsApp orders (Qatar)
  callUAE: "+971524707380",
  callQatar: "+97471929933",
  instagram: "https://instagram.com/mr_11_store"
};

const PRODUCTS = [
  {
    id: "afleyk-world-map-mini-set",
    name: "Afleyk Scents World Map Mini Set",
    category: "combo",
    price: 99,
    offer: "2 boxes for 99",
    freeDelivery: false,
    images: ["images/product-1.jpg"],
    description: "A gift box of mini perfumes in gold-capped bottles, laid out beneath a world map of scent origins. Includes Spanish Tobacco, French Tobacco and Brazilian. Two boxes for 99 AED."
  },
  {
    id: "afleyk-light-fragrance-200ml",
    name: "Afleyk Light Fragrance 200ml",
    category: "combo",
    price: 99,
    offer: "3 boxes for 99",
    freeDelivery: true,
    images: ["images/product-2.jpg"],
    description: "Signature Collection Light Fragrance in large 200 ml bottles. Comes in grey, black and pink boxes. Three boxes for 99 AED with free delivery."
  },
  {
    id: "luxury-gift-box-trio",
    name: "Luxury Gift Box Perfume Trio",
    category: "combo",
    price: 99,
    offer: "3 boxes for 99",
    freeDelivery: true,
    images: ["images/product-3.jpg"],
    description: "Three gift-boxed perfumes with gold sculpted caps, including the pink \"One & Only\" bottle. Three boxes for 99 AED with free delivery."
  },
  {
    id: "perfume-mix-10-pieces",
    name: "Perfume Mix, 10 Pieces",
    category: "combo",
    price: 149,
    offer: "10 pieces for 149",
    freeDelivery: true,
    images: ["images/product-4.jpg"],
    description: "A mixed set of 10 perfumes from top-selling lines, all 100% quality. Choose it for gifting or to stock up. 149 AED with free delivery."
  },
  {
    id: "gl-wear-x6-smart-band",
    name: "G.L Wear X6 Smart Band",
    category: "accessory",
    price: 99,
    offer: "2 pieces for 99",
    freeDelivery: false,
    images: ["images/product-5.jpg"],
    description: "Water-resistant smart band in black, blue and rose gold. Two pieces for 99 AED."
  }
];
