// Home page: offers, product grid, filter + search.
renderChrome();

const grid = document.getElementById("grid");
const empty = document.getElementById("empty");
let category = "all", query = "";

function card(p) {
  return `
  <article class="card">
    <a href="product.html?id=${p.id}" class="card-img"><img src="${p.images[0]}" alt="${p.name}" loading="lazy" onerror="imgFallback(this)"></a>
    <div class="card-body">
      <span class="tag">${p.offer}</span>
      <h3><a href="product.html?id=${p.id}">${p.name}</a></h3>
      <p class="price">${money(p.price)}${p.freeDelivery ? '<small>Free delivery</small>' : ''}</p>
      <a class="btn" href="${waLink(STORE.whatsappUAE, orderText(p))}" target="_blank" rel="noopener">Order on WhatsApp</a>
    </div>
  </article>`;
}

function render() {
  const list = PRODUCTS.filter(p =>
    (category === "all" || p.category === category) &&
    (p.name + " " + p.description).toLowerCase().includes(query));
  grid.innerHTML = list.map(card).join("");
  empty.hidden = list.length > 0;
}

document.querySelectorAll("[data-filter]").forEach(b => b.addEventListener("click", () => {
  category = b.dataset.filter;
  document.querySelectorAll("[data-filter]").forEach(x => x.setAttribute("aria-pressed", x === b));
  render();
}));
document.getElementById("search").addEventListener("input", e => { query = e.target.value.trim().toLowerCase(); render(); });

// Offer list comes from product data so it never goes out of date.
document.getElementById("offer-list").innerHTML = PRODUCTS.map(p =>
  `<li><a href="product.html?id=${p.id}"><strong>${p.offer}</strong><span>${p.name}</span></a></li>`).join("");

document.getElementById("contact-list").innerHTML = `
  <a class="btn" href="tel:${STORE.callUAE}">Call UAE · 0524707380</a>
  <a class="btn" href="${waLink(STORE.whatsappUAE, `Hello ${STORE.name}`)}" target="_blank" rel="noopener">WhatsApp UAE · 0561871837</a>
  <a class="btn ghost" href="tel:${STORE.callQatar}">Call Qatar · +974 7192 9933</a>
  <a class="btn ghost" href="${waLink(STORE.whatsappQatar, `Hello ${STORE.name}`)}" target="_blank" rel="noopener">WhatsApp Qatar</a>`;
render();
